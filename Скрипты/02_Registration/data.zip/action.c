Action()
{

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(15);

	lr_start_transaction("01_SignUp_Button");

	web_url("sign up now", 
		"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/home.html", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_end_transaction("01_SignUp_Button",LR_AUTO);

	lr_think_time(110);

	lr_start_transaction("02_Enter_Information");

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=fgh", ENDITEM, 
		"Name=password", "Value=fgh", ENDITEM, 
		"Name=passwordConfirm", "Value=fgh", ENDITEM, 
		"Name=firstName", "Value=fgh", ENDITEM, 
		"Name=lastName", "Value=fgh", ENDITEM, 
		"Name=address1", "Value=fgh", ENDITEM, 
		"Name=address2", "Value=fgh", ENDITEM, 
		"Name=register.x", "Value=76", ENDITEM, 
		"Name=register.y", "Value=11", ENDITEM, 
		LAST);

	lr_end_transaction("02_Enter_Information",LR_AUTO);

	lr_think_time(21);

	lr_start_transaction("03_Login");

	web_url("button_next.gif", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("03_Login",LR_AUTO);

	return 0;
}